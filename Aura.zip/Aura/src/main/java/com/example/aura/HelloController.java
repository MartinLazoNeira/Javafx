package com.example.aura;

import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;

public class HelloController {
    @FXML
    private Label welcomeText;

    @FXML
    private ComboBox ciudades;

    @FXML
    protected void onHelloButtonClick() {


        welcomeText.setText("");
    }

    public void initialize() {

        ciudades.getItems().addAll(
                "Santiago",
                "Viña del mar",
                "Quillota",
                "Concepción",
                "La serena"
        );

    }
}