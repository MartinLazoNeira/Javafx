module com.example.aura {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.aura to javafx.fxml;
    exports com.example.aura;
}