package com.example.rocketleague;

import javafx.fxml.FXML;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class Controller {
    @FXML
    private Label welcomeText;

    @FXML
    private ChoiceBox plataform;

    @FXML
    private ChoiceBox rank;

    @FXML
    private TextField horas;

    @FXML
    private TextField name;

    @FXML
    protected void onHelloButtonClick() {
        welcomeText.setText("Welcome to JavaFX Application!");
    }

    public void initialize() {

        plataform.getItems().addAll(
                "🖱️ Steam",
                "🖱️ Epic Games",
                "🎮 Xbox",
                "🎮 PlayStation"
        );

        rank.getItems().addAll(
                "Bronce",
                "Plata",
                "Oro",
                "Platino",
                "Diamante",
                "Champion (C)",
                "Grand Champion (GC)",
                "Super Sonic Legend(SSL)"
        );

    }
}
