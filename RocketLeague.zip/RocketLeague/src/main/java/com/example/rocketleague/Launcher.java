package com.example.rocketleague;

import javafx.application.Application;

public class Launcher {
    public static void main(String[] args) {
        Application.launch(RocketApplication.class, args);
    }
}
