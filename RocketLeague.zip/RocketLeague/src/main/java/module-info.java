module com.example.rocketleague {
    requires javafx.controls;
    requires javafx.fxml;

    requires org.kordamp.bootstrapfx.core;

    opens com.example.rocketleague to javafx.fxml;
    exports com.example.rocketleague;
}